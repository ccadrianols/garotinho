from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
import pandas as pd
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'sua_chave_super_secreta'

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

users_db = {}
USUARIOS_CSV = 'usuarios.csv'
ATENDIMENTOS_CSV = 'uploads/atendimentos.csv'

class User(UserMixin):
    def __init__(self, username, fullname, password_hash):
        self.id = username
        self.username = username
        self.fullname = fullname
        self.password_hash = password_hash

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

def carregar_usuarios():
    if os.path.exists(USUARIOS_CSV):
        df = pd.read_csv(USUARIOS_CSV)
        for _, row in df.iterrows():
            users_db[row['username']] = User(row['username'], row['fullname'], row['password_hash'])

def salvar_usuario(user):
    df = pd.DataFrame([{
        'username': user.username,
        'fullname': user.fullname,
        'password_hash': user.password_hash
    }])
    header = not os.path.exists(USUARIOS_CSV)
    df.to_csv(USUARIOS_CSV, mode='a', index=False, header=header)

@login_manager.user_loader
def load_user(user_id):
    return users_db.get(user_id)

@app.route('/')
@login_required
def index():
    if not os.path.exists(ATENDIMENTOS_CSV):
        df = pd.DataFrame(columns=['Nome', 'Cidade', 'Telefone', 'Email', 'Status', 'Responsável', 'DataHoraUltimoAtendimento'])
        os.makedirs('uploads', exist_ok=True)
        df.to_csv(ATENDIMENTOS_CSV, index=False)
    df = pd.read_csv(ATENDIMENTOS_CSV)
    pendentes = df[(df['Status'].isna()) | (df['Status'] == '') | (df['Status'] == 'Pendente')]
    return render_template('index.html', pendentes_count=len(pendentes), user=current_user)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        fullname = request.form.get('fullname')
        username = request.form.get('username')
        password = request.form.get('password')
        if username in users_db:
            flash('Usuário já existe.')
            return redirect(url_for('register'))
        password_hash = generate_password_hash(password)
        user = User(username, fullname, password_hash)
        users_db[username] = user
        salvar_usuario(user)
        flash('Cadastro realizado com sucesso! Faça login.')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = users_db.get(username)
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('index'))
        flash('Usuário ou senha inválidos.')
        return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/cliente')
@login_required
def cliente():
    if not os.path.exists(ATENDIMENTOS_CSV):
        df = pd.DataFrame(columns=['Nome', 'Cidade', 'Telefone', 'Email', 'Status', 'Responsável', 'DataHoraUltimoAtendimento'])
        os.makedirs('uploads', exist_ok=True)
        df.to_csv(ATENDIMENTOS_CSV, index=False)
    df = pd.read_csv(ATENDIMENTOS_CSV)
    pendentes = df[(df['Status'].isna()) | (df['Status'] == '') | (df['Status'] == 'Pendente')]
    if not pendentes.empty:
        cliente = pendentes.iloc[0].to_dict()
    else:
        cliente = None
    return render_template('cliente.html', cliente=cliente)

@app.route('/atender', methods=['POST'])
@login_required
def atender():
    nome = request.form.get('nome')
    df = pd.read_csv(ATENDIMENTOS_CSV)
    idx = df.index[df['Nome'] == nome].tolist()
    if idx:
        i = idx[0]
        df.at[i, 'Status'] = 'Atendido'
        df.at[i, 'Responsável'] = current_user.username
        df.at[i, 'DataHoraUltimoAtendimento'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        df.to_csv(ATENDIMENTOS_CSV, index=False)
    return redirect(url_for('cliente'))

@app.route('/pular', methods=['POST'])
@login_required
def pular_cliente():
    nome_cliente = request.form.get('nome')
    df = pd.read_csv(ATENDIMENTOS_CSV)
    idx = df.index[df['Nome'] == nome_cliente].tolist()
    if idx:
        i = idx[0]
        df.at[i, 'Status'] = 'Pulado'
        df.at[i, 'Responsável'] = current_user.username
        df.at[i, 'DataHoraUltimoAtendimento'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        df.to_csv(ATENDIMENTOS_CSV, index=False)
    return redirect(url_for('cliente'))

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    if not os.path.exists(USUARIOS_CSV):
        # Criar CSV de usuários vazio na primeira execução
        df_users = pd.DataFrame(columns=['username', 'fullname', 'password_hash'])
        df_users.to_csv(USUARIOS_CSV, index=False)

    carregar_usuarios()
    app.run(debug=True)
