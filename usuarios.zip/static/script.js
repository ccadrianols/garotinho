async function fetchStatusData() {
  const response = await fetch('/status_data');
  const data = await response.json();
  return data;
}

async function createChart() {
  const statusData = await fetchStatusData();

  const ctx = document.getElementById('statusChart').getContext('2d');
  const chart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: Object.keys(statusData),
      datasets: [{
        label: 'Quantidade',
        data: Object.values(statusData),
        backgroundColor: ['#f39c12', '#3498db', '#2ecc71']
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true }
      }
    }
  });
}

createChart();
